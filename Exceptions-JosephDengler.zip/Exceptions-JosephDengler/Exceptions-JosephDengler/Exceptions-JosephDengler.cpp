// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <iostream>
#include <stdexcept> // Required for standard exceptions

// Function that performs additional custom logic
bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Throwing a runtime error to simulate a failure
    throw std::runtime_error("Something went wrong in even more custom logic!");

    return true; // This line will not be reached due to the thrown exception
}

// Function to execute custom logic with appropriate error handling
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e)
    {
        std::cerr << "Caught exception: " << e.what() << std::endl;
    }

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explicitly in main
    class CustomException : public std::exception
    {
    public:
        const char* what() const noexcept override
        {
            return "Custom Exception occurred!";
        }
    };

    // Throwing a custom exception
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

// Function to divide two numbers with exception handling for divide by zero
float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    if (den == 0)
    {
        throw std::invalid_argument("Division by zero is undefined.");
    }

    return (num / den);
}

// Function to call divide with error handling for exceptions related to division
void do_division() noexcept
{
    // TODO: Create an exception handler to capture ONLY the exception thrown by divide.
    float numerator = 10.0f;
    float denominator = 0;

    try
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& e)
    {
        std::cerr << "Caught exception in division: " << e.what() << std::endl;
    }
}

int main()
{
    try
    {
        std::cout << "Exceptions Tests!" << std::endl;

        // Perform division with error handling
        do_division();

        // Perform custom logic with error handling
        do_custom_application_logic();
    }
    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception
    //  that wraps the whole main function, and displays a message to the console.
    catch (const std::exception& e)
    {
        std::cerr << "Caught a standard exception in main: " << e.what() << std::endl;
    }
    catch (...)
    {
        std::cerr << "Caught an unknown exception in main." << std::endl;
    }

    return 0;
}