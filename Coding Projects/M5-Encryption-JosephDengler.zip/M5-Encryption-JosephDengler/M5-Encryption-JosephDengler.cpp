// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

// Encrypt or decrypt a source string using the provided key
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    // Get lengths now instead of calling the function every time
    const auto key_length = key.length();
    const auto source_length = source.length();

    // Ensure that key and source strings are not empty
    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // Loop through the source string character by character
    for (size_t i = 0; i < source_length; ++i)
    {
        output[i] = source[i] ^ key[i % key_length];
    }

    // Our output length must match the source length
    assert(output.length() == source_length);
    return output;
}

// Load data from the specified file into a string
std::string read_file(const std::string& filename)
{
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error: Unable to open file " << filename << std::endl;
        return "";
    }

    // Read entire file content into a string
    std::string data((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
    file.close();
    return data;
}

// Extract student name from the data string
std::string get_student_name(const std::string& data)
{
    // Find the first newline character in the data
    size_t position = data.find('\n');
    if (position != std::string::npos) {
        return data.substr(0, position);
    }

    // If no newline is found, return an empty string
    return "";
}

// Save the data to a file in the specified format
void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    std::ofstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error: Unable to open file " << filename << std::endl;
        return;
    }

    // Get the current time in a safe manner
    std::time_t now = std::time(nullptr);
    std::tm time_info;
    localtime_s(&time_info, &now);
    char buffer[11];
    std::strftime(buffer, sizeof(buffer), "%Y-%m-%d", &time_info);

    // Write data to the file in the specified format
    file << student_name << "\n";
    file << buffer << "\n";
    file << key << "\n";
    file << data;

    file.close();
    std::cout << "Data successfully saved to " << filename << std::endl;
}

int main()
{
    std::cout << "Encryption Decryption Test!" << std::endl;

    // Absolute file paths for testing
    const std::string input_file_path = "D:\\CS405\\M5-Encryption-JosephDengler\\x64\\Debug\\inputdatafile.txt";
    const std::string encrypted_file_path = "D:\\CS405\\M5-Encryption-JosephDengler\\x64\\Debug\\encrypteddatafile.txt";
    const std::string decrypted_file_path = "D:\\CS405\\M5-Encryption-JosephDengler\\x64\\Debug\\decrypteddatafile.txt";
    const std::string encryption_key = "password";

    // Attempt to read the source data from the input file
    std::cout << "Attempting to open file: " << input_file_path << std::endl;
    const std::string source_data = read_file(input_file_path);

    // Validate that the data was successfully read
    if (source_data.empty()) {
        std::cerr << "Error: Source string is empty. Exiting..." << std::endl;
        return 1;
    }

    // Extract the student name from the source data
    const std::string student_name = get_student_name(source_data);
    if (student_name.empty()) {
        std::cerr << "Error: Student name is empty. Exiting..." << std::endl;
        return 1;
    }

    // Encrypt the source data using the provided key
    const std::string encrypted_data = encrypt_decrypt(source_data, encryption_key);

    // Save the encrypted data to the encrypted output file
    save_data_file(encrypted_file_path, student_name, encryption_key, encrypted_data);

    // Decrypt the encrypted data to verify correctness
    const std::string decrypted_data = encrypt_decrypt(encrypted_data, encryption_key);

    // Save the decrypted data to the decrypted output file
    save_data_file(decrypted_file_path, student_name, encryption_key, decrypted_data);

    // Display final paths to the console for user verification
    std::cout << "Read File: " << input_file_path << " - Encrypted To: " << encrypted_file_path << " - Decrypted To: " << decrypted_file_path << std::endl;

    return 0;
}
